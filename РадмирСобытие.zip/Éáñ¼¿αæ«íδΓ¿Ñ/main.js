document.addEventListener('DOMContentLoaded', function() {
    let field = document.getElementById('field');
    let ball = document.getElementById('ball');
    
    field.addEventListener('click', function(event) {
      let fieldRect = field.getBoundingClientRect();
     let ballRect = ball.getBoundingClientRect();
      
      let fieldLeft = fieldRect.left;
      let fieldTop = fieldRect.top;
      let fieldRight = fieldRect.right;
      let fieldBottom = fieldRect.bottom;
  
      let ballLeft = ballRect.left;
      let ballTop = ballRect.top;
      
      let mouseX = event.clientX;
      let mouseY = event.clientY;
      
      let ballX = mouseX - fieldLeft - ball.offsetWidth/2;
      let ballY = mouseY - fieldTop - ball.offsetHeight/2;
      
      if (ballX < 0) {
        ballX = 0;
      } else if (ballX > field.offsetWidth - ball.offsetWidth) {
        ballX = field.offsetWidth - ball.offsetWidth;
      }
      
      if (ballY < 0) {
        ballY = 0;
      } else if (ballY > field.offsetHeight - ball.offsetHeight) {
        ballY = field.offsetHeight - ball.offsetHeight;
      }
      
      ball.style.left = ballX + 'px';
      ball.style.top = ballY + 'px';
    });
  });